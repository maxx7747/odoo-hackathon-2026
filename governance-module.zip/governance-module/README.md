# EcoSphere — Governance Module

A working implementation of the **Governance module** for the EcoSphere ESG Management Platform hackathon problem statement.

Covers:
- **Policies** — create/edit ESG governance policies, versioned, Draft → Active → Archived
- **Policy Acknowledgements** — assign a policy to an employee, track Pending/Acknowledged, send reminder notifications
- **Audits** — schedule and track governance audits by department
- **Compliance Issues** — every issue requires an **owner** and a **due date**; issues past their due date while still Open are automatically flagged as **Overdue**
- **Notifications** — in-app notifications for: new compliance issue raised, policy acknowledgement reminders, overdue compliance issues
- **Departments & Employees** — supporting master data used across the module

## Tech stack

- **Backend:** Node.js + Express + better-sqlite3 (file-based SQL database, zero setup — no external DB server needed)
- **Frontend:** Plain HTML/CSS/JavaScript (no framework/build step, served as static files by Express)
- No authentication — this module keeps Owner/Role as plain data fields, as scoped for the hackathon submission.

## Project structure

```
governance-module/
├── backend/
│   ├── server.js              # Express app entry point
│   ├── db.js                  # SQLite connection + schema (auto-creates tables)
│   ├── notify.js              # Notification helper + overdue-issue scanner
│   ├── seed.js                # Optional sample data loader
│   ├── package.json
│   └── routes/
│       ├── departments.js
│       ├── employees.js
│       ├── policies.js
│       ├── acknowledgements.js
│       ├── audits.js
│       ├── complianceIssues.js
│       └── notifications.js
└── frontend/
    ├── index.html
    ├── styles.css
    └── app.js
```

## Getting started

```bash
cd backend
npm install
npm run seed     # optional: loads sample departments, employees, policies, audits, issues
npm start
```

Then open **http://localhost:4000** in your browser. The Express server serves both the API (`/api/...`) and the frontend from the same port, so there's nothing else to run.

The SQLite database file (`backend/governance.db`) is created automatically on first run — no separate database installation required.

## API overview

All endpoints are under `/api`:

| Resource | Endpoints |
|---|---|
| Departments | `GET/POST /departments`, `GET/PUT/DELETE /departments/:id` |
| Employees | `GET/POST /employees`, `GET/PUT/DELETE /employees/:id` |
| Policies | `GET/POST /policies`, `GET/PUT/DELETE /policies/:id` |
| Acknowledgements | `GET/POST /acknowledgements`, `PUT /acknowledgements/:id/acknowledge`, `DELETE /acknowledgements/:id`, `POST /acknowledgements/send-reminders` |
| Audits | `GET/POST /audits`, `GET/PUT/DELETE /audits/:id` |
| Compliance Issues | `GET/POST /compliance-issues`, `GET/PUT/DELETE /compliance-issues/:id` |
| Notifications | `GET /notifications`, `GET /notifications/unread-count`, `PUT /notifications/:id/read`, `PUT /notifications/read-all` |

## Business rules implemented

- A Compliance Issue **cannot be created without an owner and a due date** (enforced server-side, returns `400` otherwise).
- Every time compliance issues are fetched (or notifications are polled), the backend checks for **Open** issues whose `due_date` has passed and flags them as overdue exactly once (`overdue_notified` flag prevents duplicate notifications). Changing the due date on an issue re-arms this check.
- Creating a new Compliance Issue automatically raises an in-app notification.
- "Send Reminders" on the Policy Acknowledgements screen creates a reminder notification for every employee with a Pending acknowledgement.
- The frontend polls `/api/notifications` and `/api/compliance-issues` every 30 seconds to surface new alerts without a manual refresh.

## Notes for extending this for the full hackathon submission

This repo only implements the **Governance module** slice of the EcoSphere platform (per the assigned scope in the problem statement — Environmental, Social, and Gamification modules are out of scope here). The data model follows the same `Department` / `Employee` master-data conventions described in the problem statement's suggested data model, so it should be straightforward to merge with Environmental/Social/Gamification modules built by teammates into a single database and dashboard later.
